﻿using System;
using static System.Console;
namespace Molina_StudentStudyApp
{
    public class Info
    {
        public void AssignementInfo()
        {
            Clear();
            WriteLine("******************************************************\n");
            WriteLine("{0,-15}Barry Molina", "Name:");
            WriteLine("{0,-15}ITDEV-115-200", "Course:");
            WriteLine("{0,-15}J. Christie", "Instructor:");
            WriteLine("{0,-15}Assignment 5 - Student Study App", "Assignment:");
            WriteLine("{0,-15}2/28/2020", "Date:");
            WriteLine("\n******************************************************\n");
        }
    }
}
