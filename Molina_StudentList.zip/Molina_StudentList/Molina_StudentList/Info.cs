﻿using System;
using static System.Console;
namespace Molina_StudentList
{
    public class Info
    {
        public void AssignmentInfo()
        {
            Clear();
            WriteLine("******************************************************\n");
            WriteLine("{0,-15}Barry Molina", "Name:");
            WriteLine("{0,-15}ITDEV-115-200", "Course:");
            WriteLine("{0,-15}J. Christie", "Instructor:");
            WriteLine("{0,-15}Final Program", "Assignment:");
            WriteLine("{0,-15}5/14/2020", "Date:");
            WriteLine("\n******************************************************\n\n\n");
        }
    }
}
